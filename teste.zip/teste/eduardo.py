n1 = int(input("Digite o primeiro número: "))
print(f'seu numero E {n1}')